(function() {
    $(document).ready(function() {
        $('.kareui-accordion').each(function() {
            uiInit($(this));
            $(this).attr('kareui-init', 'true')
        })
		$('.ku-btn-close').on('click', function(e){
			$('.kareui-accordion .ku-card').attr('kareui-status', 'close');
			uiActive($('.kareui-accordion'));
		});
        function uiInit($ui) {
            $ui.find('.ku-card').on('click', function() {
                $ui.find('.ku-card').attr('kareui-status', 'close');
                $(this).attr('kareui-status', 'open');
                uiActive($ui)
            });
            uiActive($ui)
        }
        function uiActive($ui, activeIdx) {
            $ui.find('.ku-card').each(function() {
                var $card = $(this);
                var isInit = ($ui.attr('kareui-init') == 'true');
                console.log(isInit, $ui.attr('kareui-init'), $card.attr('kareui-status'));
                if ($card.attr('kareui-status') == 'open') {
					if(isInit){
						$card.find('.ku-card-body').slideDown('700','easeInOutCubic');
					}else{
						$card.find('.ku-card-body').show();
					}
                } else {
                    $card.attr('kareui-status', 'close');
					if(isInit){
						$card.find('.ku-card-body').slideUp('700','easeInOutCubic');
					}else{
						$card.find('.ku-card-body').hide();
					}
                }
            })
        }
    })
})()